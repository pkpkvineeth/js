const express=require('express');
const bookRouter=express.Router();
const book=[{title:'Pride and Prejudice',author:'Jane Austen',genre:'	Classic Regency novel'},{title:'Beowulf',author:'Unknown',genre:'Epic heroic writing'},{title:'Nineteen Eighty-Four',author:'George Orwell',genre:'	Dystopian, political fiction, social science fiction'}];
const navs=[{link:'/books',title:"Books"},{link:'/authors',title:"Author"},{link:'/about',title:"About Us"},{link:'/contact',title:"Contact Us"}];
bookRouter.route('/').get((req,res)=>{
    res.render('book',{books:book,
    nav:navs,
    title:"Books"});
})
bookRouter.route('/:id').get((req,res)=>{
    const id=req.params.id;
    res.render('singlebook',{singleBooks:book[id],nav:navs});
})
module.exports=bookRouter;