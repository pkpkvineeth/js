function router(nav)
{
const express=require('express');
const bookRouter=express.Router();
const book=[{title:'Pride and Prejudice',author:'Jane Austen',genre:'	Classic Regency novel'},{title:'Beowulf',author:'Unknown',genre:'Epic heroic writing'},{title:'Nineteen Eighty-Four',author:'George Orwell',genre:'	Dystopian, political fiction, social science fiction'}];
bookRouter.route('/').get((req,res)=>{
    res.render('book',{books:book,
    nav:nav,
    title:"Books"});
})
bookRouter.route('/:id').get((req,res)=>{
    const id=req.params.id;
    res.render('singlebook',{singleBooks:book[id],nav});
})
return bookRouter;
}
module.exports=router;