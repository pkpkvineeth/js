function router(nav)
{
const express=require('express');
const authorRouter=express.Router();
const author=[{name:"Jane Austen",period:"1787-1811",works:"Pride and Prejudice,Sense and Sensibility,Emma"},{name:"George Orwell",period:"1928–1950",works:"Animal Farm,Nineteen Eighty-Four,Homage to Catalonia"},{name:"William Shakespeare",period:"1564-1616",works:"Hamlet , ‎Macbeth , ‎Romeo and Juliet , ‎The Sonnets"}]
authorRouter.route('/').get((req,res)=>{
    res.render("authors",{author,nav,title:"Authors"});
})
authorRouter.route('/:id').get((req,res)=>{
    const id=req.params.id;
    res.render("singleauthor",{singleAuthor:author[id],nav});
})
return authorRouter;
}
module.exports=router;