function router(nav)
{
    const express=require('express');
    const contactRouter=express.Router();
    contactRouter.route('/').get((req,res)=>{
        res.render('contact',{nav,title:"Contact Us"})
    })
    return contactRouter;
}
module.exports=router;