function route(nav)
{
    const express=require('express');
    const addbookRouter=express.Router();
    addbookRouter.route('/').get((req,res)=>{
        res.render('book_add',{nav,title:"Add book"});
    })
    addbookRouter.route('/addbookdata').get((req,res)=>{
        res.send('Successfully added');
    })
    return addbookRouter;
}
module.exports=route;