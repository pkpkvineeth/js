function router(nav)
{
    const express=require('express');
    const aboutRouter=express.Router();
    aboutRouter.route('/').get((req,res)=>{
        res.render('about',{nav,title:"About Us"});
    })
    return aboutRouter;
}
module.exports=router;
