const express=require('express');
const chalk = require('chalk');
const path = require('path');
const bookRouter=require('./src/routes/bookRoute')
const authorRouter=require('./src/routes/authorRouter')
var app= new express();
app.set('views','./src/views');
app.set('view engine','ejs');
app.use(express.static(path.join(__dirname,"/public")));
app.use('/books',bookRouter);
app.use('/authors',authorRouter);
app.get('/',function(req,res){
    res.render('index',{nav:[{link:'/books',title:"Books"},{link:'/authors',title:"Author"},{link:'/about',title:"About Us"},{link:'/contact',title:"Contact Us"}],
    title:"Library"
});
})
app.listen(3500,function(){
    console.log("Listening to port "+chalk.green('3500')+"...................");
})