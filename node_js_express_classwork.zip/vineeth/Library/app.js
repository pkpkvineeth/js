const express=require('express');
const chalk = require('chalk');
const path = require('path');
const nav=[{link:'/books',title:"Books"},{link:'/authors',title:"Author"},{link:'/about',title:"About Us"},{link:'/contact',title:"Contact Us"},{link:'/addbook',title:"Add Book"}]
const bookRouter=require('./src/routes/bookRoute')(nav);
const authorRouter=require('./src/routes/authorRouter')(nav);
const aboutRouter=require('./src/routes/aboutRouter')(nav);
const contactRouter=require('./src/routes/contactRouter')(nav);
const addbookRouter=require('./src/routes/addbook')(nav);
var app= new express();
app.set('views','./src/views');
app.set('view engine','ejs');
app.use(express.static(path.join(__dirname,"/public")));
app.use('/books',bookRouter);
app.use('/authors',authorRouter);
app.use('/about',aboutRouter);
app.use('/contact',contactRouter);
app.use('/addbook',addbookRouter);
app.get('/',function(req,res){
    res.render('index',{nav,
    title:"Library"
});
})
app.listen(3500,function(){
    console.log("Listening to port "+chalk.green('3500')+"...................");
})