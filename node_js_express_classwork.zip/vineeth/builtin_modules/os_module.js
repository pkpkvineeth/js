var os=require('os');
var gbt=os.totalmem()/(1024*1024*1024);
console.log("TOTAL MEMORY:"+gbt);
var gbf=os.freemem()/(1024*1024*1024);
console.log("FREE MEMORY:"+gbf);