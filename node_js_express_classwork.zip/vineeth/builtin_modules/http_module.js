var http =require('http');
var server = http.createServer();
server.listen(4000);
console.log("Listening to port 4000");