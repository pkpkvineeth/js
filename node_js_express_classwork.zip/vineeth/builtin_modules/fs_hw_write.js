const fs=require('fs');
fs.readdir('./',function(err,files){
    if(err){
        console.log("ERROR"+err);
    }
    else
    {
        console.log(`readdir:${files}`);
    }
});
var files=fs.readdirSync('./');
console.log(`readdirSync:${files}`);
