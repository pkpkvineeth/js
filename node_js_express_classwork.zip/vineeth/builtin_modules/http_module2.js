var http =require('http');
var server = http.createServer(function(req,res){
    if(req.url=='/')
    {
    res.write("Hello World");
    res.end();
    }
    if(req.url=="/users")
    {
        res.write(JSON.stringify([1,2,3]));
        res.end();
    }
});
server.listen(4000);
console.log("Listening to port 4000");