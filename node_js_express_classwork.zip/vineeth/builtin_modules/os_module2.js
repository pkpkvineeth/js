//template string
const os=require('os');
var freemem=os.freemem();
var totmeme=os.totalmem();
console.log(`Total Memory = ${totmeme}`);
console.log(`Free Memory = ${freemem}`)