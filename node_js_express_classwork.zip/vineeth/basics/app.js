var logger=require('./logger.js')
logger.display("Hello");