var curren_date=require('./date_module_2')
console.log(curren_date.myD());