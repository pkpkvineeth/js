function myDateTime()
{
    return Date();
}
module.exports.myD=myDateTime;