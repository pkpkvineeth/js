var logger=require('./date_module.js')
console.log(logger.myDateTime());